#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CF2 Analyzer & Summarizer 0.7: metadatos interpretables, sin selección.

Entrada: corpus_metrics.csv o archivos CF2 originales (el segundo modo requiere numpy).
Salida por altavoz: metadata.json, bands.csv, summary.md.
También: catalogo_altavoces.csv, catalogo_bandas.csv, resumen_corpus.md, metadatos_ejecucion.json.
Se reutiliza cf2_summarizer.py v0.6 para la deduplicación y la lectura CF2.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

import cf2_summarizer as baseline

VERSION = '0.7.0'
HERE = Path(__file__).resolve().parent
FREQUENCIES = tuple(float(x) for x in baseline.CF2_FREQS)


def val(row:dict, col:str)->float:
    return baseline.val(row,col)


def show(x:float, decimals=1)->str:
    return baseline.fmt(baseline.num(x),decimals).replace('.', ',')


def freq_name(x:float)->str:
    return baseline.frequency_name(x)


def safe(value):
    return baseline.safe_json(value)


def norm_class(di:float, cfg:dict)->str:
    if not math.isfinite(di): return 'no determinado'
    if di<0: return 'índice axial negativo'
    a,b,c = cfg['di_categories_db']
    if di<a: return 'poco directivo'
    if di<b: return 'moderadamente directivo'
    if di<c: return 'directivo'
    return 'muy directivo'


def width_class(width:float,cfg:dict)->str:
    if not math.isfinite(width): return 'no delimitada a −6 dB'
    a,b,c=cfg['width_categories_deg']
    if width<a:return 'estrecha'
    if width<b:return 'intermedia'
    if width<c:return 'amplia'
    return 'muy amplia'


def spectral_group(f:float,cfg:dict)->str:
    if f<=cfg['low_band_upper_hz']:return 'bajas'
    if f<=cfg['mid_band_upper_hz']:return 'medias'
    return 'altas'


def contiguous(f1:float,f2:float)->bool:
    try:
        return FREQUENCIES.index(f2)-FREQUENCIES.index(f1)==1
    except ValueError:
        return False


def classify_band(row:dict, config:dict,prev:dict|None=None)->dict:
    f=val(row,'frequency_hz')
    di=val(row,'di_integrated_db');gain=val(row,'peak_off_axis_db')
    di_max=di+gain if math.isfinite(di) and math.isfinite(gain) else math.nan
    h=val(row,'h_width_deg');v=val(row,'v_width_deg')
    rear=val(row,'rear_power_pct');front=val(row,'front_cone_60_power_pct')
    q=val(row,'q_integrated')
    arc=val(row,'peak_arc_deg')
    shift=math.isfinite(gain) and gain>config['off_axis_db_min']
    class_di=norm_class(di,config);class_max=norm_class(di_max,config)
    limits=[]
    if not math.isfinite(di) or not math.isfinite(q) or q<=0:
        limits.append('No se dispone de DI/Q físicamente interpretables.')
    if not (math.isfinite(h) and math.isfinite(v)):
        limits.append('Uno o ambos anchos a −6 dB no están delimitados; no equivalen a 360°.')
    if any(math.isfinite(x) and x<=10 for x in (h,v)):
        limits.append('Al menos un ancho es próximo al paso angular CF2 de 5°.')
    if shift:
        limits.append('La cobertura referida al eje frontal puede no caracterizar el haz principal desplazado.')
    qerr=val(row,'ea_q_relative_error_pct')
    herr=val(row,'ea_h_width_error_abs_deg');verr=val(row,'ea_v_width_error_abs_deg')
    qc=str(row.get('quality_status','')).lower()
    serious=qc in ('invalid','error') or not math.isfinite(di) or not math.isfinite(q) or q<=0
    if math.isfinite(qerr) and qerr>config['ea_q_discrepancy_review_pct']:
        serious=True;limits.append('La comparación interna con Q de EA supera el umbral de revisión.')
    if any(math.isfinite(x) and x>config['ea_width_discrepancy_review_deg'] for x in (herr,verr)):
        serious=True;limits.append('La comparación interna de ancho de haz con EA requiere revisión.')
    if 'inconsistent_poles' in str(row.get('quality_flags','')).lower():
        serious=True;limits.append('Consistencia entre polos del patrón pendiente de revisión.')
    status='revisar' if serious else ('condicionado' if limits else 'interpretable')
    if math.isfinite(di):
        short=f'A {freq_name(f)}, {class_di} respecto al eje (DI axial {show(di,2)} dB)'
    else:
        short=f'A {freq_name(f)}, directividad axial no determinada'
    if shift:
        short+=f'; el máximo supera al eje frontal en {show(gain,1)} dB'
    elif math.isfinite(h) and math.isfinite(v) and min(h,v)>0:
        ratio=max(h,v)/min(h,v)
        if ratio>=config['anisotropy_ratio_min']:
            short+='; coberturas muy diferentes entre los dos cortes'
        else:
            short+='; coberturas de magnitud comparable entre cortes'
    short+='.'
    tech=[]
    if math.isfinite(di):tech.append(f'DI axial {show(di,2)} dB')
    if math.isfinite(q):tech.append(f'Q axial {show(q,2)}')
    if math.isfinite(di_max):tech.append(f'DI en la dirección del máximo {show(di_max,2)} dB')
    if math.isfinite(gain) and math.isfinite(arc):
        tech.append(f'máximo +{show(gain,2)} dB frente al eje, a {show(arc,0)}° de arco')
    tech.append('ancho axial a −6 dB en cortes provisionales H/V: '
                +f'{show(h)}° / {show(v)}°')
    if math.isfinite(front):tech.append(f'{show(front,1)} % de potencia angular relativa en cono frontal ±60°')
    if math.isfinite(rear):tech.append(f'{show(rear,1)} % en hemisferio posterior')
    technical='; '.join(tech)+'.'
    interpretation=[]
    if shift:
        interpretation.append('El máximo de radiación no está bien representado por el nivel axial; '
                              'es necesario considerar la orientación de la fuente.')
    elif math.isfinite(h) and math.isfinite(v) and min(h,v)>0:
        if max(h,v)/min(h,v)>=config['anisotropy_ratio_min']:
            larger='H' if h>v else 'V'
            interpretation.append('La radiación se distribuye más ampliamente en el corte '
                                  f'{larger} que en el otro, según la convención angular provisional.')
        else:
            interpretation.append('Los dos anchos de corte son comparables; esto no prueba simetría tridimensional.')
    else:
        interpretation.append('No es posible describir ambos anchos mediante el criterio axial de −6 dB.')
    if math.isfinite(front) and front>=config['front60_pct_high_min']:
        interpretation.append('La potencia angular relativa está fuertemente concentrada en el cono frontal ±60°.')
    if math.isfinite(rear):
        if rear<=config['rear_pct_low_max']:
            interpretation.append('La fracción de potencia angular posterior es reducida.')
        elif rear>=config['rear_pct_high_min']:
            interpretation.append('Una fracción apreciable de la potencia angular se encuentra detrás del eje frontal.')
    loh=val(row,'h_lobe_candidates_count');lov=val(row,'v_lobe_candidates_count')
    lobes=[]
    if math.isfinite(loh) and loh>0:lobes.append(f'{int(loh)} candidato(s) en el corte H')
    if math.isfinite(lov) and lov>0:lobes.append(f'{int(lov)} candidato(s) en el corte V')
    if lobes:
        interpretation.append('Se observaron '+ ' y '.join(lobes)+
                              '; son máximos locales de cortes, no lóbulos 3D confirmados.')
    # Don't compare nonadjacent CF2 slots. Check that JSD belongs to actual neighbor.
    transition=None
    if prev is not None:
        prev_f=val(prev,'frequency_hz')
        recorded_prev=val(row,'previous_frequency_hz')
        if contiguous(prev_f,f):
            change=di-val(prev,'di_integrated_db') if math.isfinite(di) and math.isfinite(val(prev,'di_integrated_db')) else math.nan
            jsd=val(row,'pattern_jsd_vs_previous_bits') if math.isfinite(recorded_prev) and abs(recorded_prev-prev_f)<1e-3 else math.nan
            trend='aumenta' if math.isfinite(change) and change>=config['significant_di_change_db'] else ('disminuye' if math.isfinite(change) and change<=-config['significant_di_change_db'] else 'sin salto de DI grande')
            transition={'desde_hz':prev_f,'hasta_hz':f,'delta_di_axial_db':change,
                        'jsd_bits':jsd,'cambio_di_destacado':math.isfinite(change) and abs(change)>=config['significant_di_change_db'],
                        'cambio_espacial_destacado':math.isfinite(jsd) and jsd>=config['significant_jsd_bits']}
            if transition['cambio_di_destacado']:
                interpretation.append(f'Respecto a {freq_name(prev_f)}, el DI axial {trend} {show(abs(change),2)} dB.')
            if transition['cambio_espacial_destacado']:
                interpretation.append(f'El patrón angular cambia notablemente frente a {freq_name(prev_f)} '
                                      f'(JSD {show(jsd,3)} bits, umbral exploratorio).')
        else:
            transition={'desde_hz':prev_f,'hasta_hz':f,'contiguas':False,
                        'nota':'No son bandas contiguas; no se infiere estabilidad de un salto espectral.'}
    tags=[]
    if math.isfinite(di):tags.append('directividad_'+class_di.replace(' ','_'))
    if shift:tags.append('maximo_fuera_eje_relevante')
    if math.isfinite(h) and math.isfinite(v) and min(h,v)>0 and max(h,v)/min(h,v)>=config['anisotropy_ratio_min']:
        tags.append('cobertura_anisotropica_cortes')
    if lobes:tags.append('maximos_locales_cortes')
    if not math.isfinite(h) or not math.isfinite(v): tags.append('beamwidth_no_delimitado')
    if math.isfinite(rear) and rear<=config['rear_pct_low_max']:tags.append('fraccion_posterior_baja')
    if math.isfinite(front) and front>=config['front60_pct_high_min']:tags.append('concentracion_frontal_alta')
    metrics={name:val(row,source) for name,source in {
        'di_axial_db':'di_integrated_db','di_max_db':None,'q_axial':'q_integrated',
        'maximo_sobre_eje_db':'peak_off_axis_db','maximo_azimuth_deg':'peak_azimuth_deg',
        'maximo_arc_deg':'peak_arc_deg','beamwidth_h_deg':'h_width_deg',
        'beamwidth_v_deg':'v_width_deg','asimetria_h_deg':'h_asymmetry_deg',
        'asimetria_v_deg':'v_asymmetry_deg','energia_cono_frontal_30_pct':'front_cone_30_power_pct',
        'energia_cono_frontal_60_pct':'front_cone_60_power_pct',
        'energia_hemisferio_posterior_pct':'rear_power_pct',
        'candidatos_lobulos_h':'h_lobe_candidates_count','candidatos_lobulos_v':'v_lobe_candidates_count',
        'ea_q_error_relativo_pct':'ea_q_relative_error_pct',
        'ea_beamwidth_h_error_deg':'ea_h_width_error_abs_deg',
        'ea_beamwidth_v_error_deg':'ea_v_width_error_abs_deg'
    }.items() if source is not None}
    metrics['di_max_db']=di_max
    out={'frequency_hz':f,'region_espectral':spectral_group(f,config),
         'clasificacion_di_axial':class_di,'clasificacion_di_maximo':class_max,
         'patron_etiquetas':tags,'estado_interpretacion':status,
         'resumen_breve':short,'descripcion_tecnica':technical,
         'interpretacion_acustica':' '.join(interpretation),
         'limitaciones':list(dict.fromkeys(limits)),
         'metricas':metrics,'transicion_desde_anterior':transition,
         'resolution_angular_deg':5, 'orientacion_hv_validada':False,
         'ancho_de_haz_referido_al_eje':True,
         'candidatos_lobulos_solo_cortes':True}
    return safe(out)


def aggregate_speaker(rows:list[dict],config:dict)->dict:
    rows=sorted(rows,key=lambda r:val(r,'frequency_hz'))
    enriched=[]
    for i,row in enumerate(rows):
        enriched.append(classify_band(row,config,rows[i-1] if i else None))
    by_region=defaultdict(list)
    for band in enriched:by_region[band['region_espectral']].append(band)
    regions=[]
    for name, lo,hi in [('bajas',25,250),('medias',315,2000),('altas',2500,20000)]:
        bands=by_region.get(name,[])
        dia=[b['metricas']['di_axial_db'] for b in bands if b['metricas']['di_axial_db'] is not None]
        if not bands:
            text=f'No hay bandas declaradas entre {freq_name(lo)} y {freq_name(hi)}.'
            median_di=None
        elif dia:
            median_di=statistics.median(dia)
            text=(f'En frecuencias {name} ({freq_name(lo)}–{freq_name(hi)}), '
                  f'las {len(bands)} bandas disponibles tienen DI axial mediano de {show(median_di,2)} dB '
                  f'({norm_class(median_di,config)} según umbrales exploratorios).')
        else:
            median_di=None;text=f'En frecuencias {name}, faltan valores de DI interpretables.'
        regions.append({'region':name,'n_bandas':len(bands),'di_axial_mediana_db':median_di,'resumen':text})
    candidates=[b for b in enriched if b['metricas']['di_axial_db'] is not None]
    di_peak=max(candidates,key=lambda b:b['metricas']['di_axial_db']) if candidates else None
    maxc=[b for b in enriched if b['metricas']['di_max_db'] is not None]
    max_peak=max(maxc,key=lambda b:b['metricas']['di_max_db']) if maxc else None
    transitions=[b['transicion_desde_anterior'] for b in enriched if b['transicion_desde_anterior'] and
                 b['transicion_desde_anterior'].get('jsd_bits') is not None]
    largest=max(transitions,key=lambda x:x['jsd_bits']) if transitions else None
    shifted=sum('maximo_fuera_eje_relevante' in b['patron_etiquetas'] for b in enriched)
    anisotropy=sum('cobertura_anisotropica_cortes' in b['patron_etiquetas'] for b in enriched)
    counts=Counter(b['estado_interpretacion'] for b in enriched)
    start=rows[0]; freqs=[val(r,'frequency_hz') for r in rows]
    general=[f'{start.get("model", "Modelo sin nombre")}: se analizaron {len(rows)} bandas CF2 declaradas '
             f'entre {freq_name(min(freqs))} y {freq_name(max(freqs))}.']
    if di_peak:
        general.append(f'El mayor DI axial observado es {show(di_peak["metricas"]["di_axial_db"],2)} dB '
                       f'a {freq_name(di_peak["frequency_hz"])}.')
    general.extend(r['resumen'] for r in regions)
    if shifted:
        general.append(f'En {shifted} bandas el máximo supera al eje frontal en más de '
                       f'{show(config["off_axis_db_min"],0)} dB; no se deben describir solo mediante el DI axial.')
    if anisotropy:
        general.append(f'En {anisotropy} bandas se detectan diferencias importantes entre los anchos de dos cortes; '
                       'sus etiquetas H/V aún necesitan validación independiente.')
    if largest:
        general.append('La mayor diferencia espacial registrada entre bandas adyacentes se presenta de '
                       f'{freq_name(largest["desde_hz"])} a {freq_name(largest["hasta_hz"])} '
                       f'(JSD {show(largest["jsd_bits"],3)} bits); esto no implica calidad acústica buena o mala.')
    if counts['revisar'] or counts['condicionado']:
        general.append(f'Interpretación por banda: {counts["interpretable"]} interpretables, '
                       f'{counts["condicionado"]} condicionadas y {counts["revisar"]} a revisar.')
    summary={
        'schema_version':'cf2.directivity.speaker.v0.7',
        'methodology_version':VERSION,
        'identity':{'model':str(start.get('model','')),'manufacturer':str(start.get('manufacturer','')),
                    'filename':str(start.get('filename','')),'sha256':str(start.get('sha256','')),
                    'format':'CF2','format_version':str(start.get('version','no disponible')),
                    'source_path':str(start.get('file',''))},
        'coverage':{'declared_frequencies_hz':freqs,'n_bands':len(freqs),
                    'minimum_hz':min(freqs),'maximum_hz':max(freqs),
                    'grid_azimuth_deg':5,'grid_arc_deg':5},
        'overview':{'texto':' '.join(general),'regiones':regions,
                    'pico_di_axial_db':di_peak['metricas']['di_axial_db'] if di_peak else None,
                    'frecuencia_pico_di_axial_hz':di_peak['frequency_hz'] if di_peak else None,
                    'pico_di_max_db':max_peak['metricas']['di_max_db'] if max_peak else None,
                    'frecuencia_pico_di_max_hz':max_peak['frequency_hz'] if max_peak else None,
                    'n_bandas_maximo_fuera_eje':shifted,
                    'n_bandas_cobertura_anisotropica_cortes':anisotropy,
                    'transicion_jsd_mayor':largest,
                    'conteo_estados':dict(counts)},
        'methodology':{
            'origin_metrics_version':str(start.get('methodology_version','n/d')),
            'hv_orientation':'provisional; pendiente contraste con CLF Viewer',
            'energy':'fracciones relativas de potencia angular; no SPL absoluto',
            'frequency':'solo bandas CF2 declaradas; sin interpolar ni remuestrear',
            'thresholds':'exploratorios, no normativos',
            'validation':'comparación EA es interna al CF2, no una medición externa',
            'selection':'no se calculan rankings, idoneidad ni exclusiones de altavoces'},
        'bands':enriched}
    return summary


def band_flat(identity:dict, band:dict)->dict:
    m=band['metricas'];t=band['transicion_desde_anterior'] or {}
    return {
        'sha256':identity['sha256'],'model':identity['model'],'manufacturer':identity['manufacturer'],
        'frequency_hz':band['frequency_hz'],'region_espectral':band['region_espectral'],
        'di_axial_db':m['di_axial_db'],'di_max_db':m['di_max_db'],'q_axial':m['q_axial'],
        'beamwidth_h_deg':m['beamwidth_h_deg'],'beamwidth_v_deg':m['beamwidth_v_deg'],
        'maximo_arc_deg':m['maximo_arc_deg'],'maximo_sobre_eje_db':m['maximo_sobre_eje_db'],
        'energia_cono_frontal_60_pct':m['energia_cono_frontal_60_pct'],
        'energia_hemisferio_posterior_pct':m['energia_hemisferio_posterior_pct'],
        'clasificacion_di_axial':band['clasificacion_di_axial'],
        'clasificacion_di_maximo':band['clasificacion_di_maximo'],
        'etiquetas':'|'.join(band['patron_etiquetas']),
        'estado_interpretacion':band['estado_interpretacion'],
        'delta_di_adyacente_db':t.get('delta_di_axial_db'),
        'jsd_adyacente_bits':t.get('jsd_bits'),
        'descripcion_breve':band['resumen_breve'],
        'descripcion_tecnica':band['descripcion_tecnica'],
        'interpretacion_acustica':band['interpretacion_acustica'],
        'limitaciones':'|'.join(band['limitaciones'])}


def markdown_report(profile:dict)->str:
    identity=profile['identity'];cov=profile['coverage'];ov=profile['overview'];bands=profile['bands']
    t=[f'# Perfil de directividad — {identity["model"]}','',
       f'**Fabricante:** {identity["manufacturer"]}  ',
       f'**Archivo:** `{identity["filename"]}`  ',
       f'**SHA-256:** `{identity["sha256"]}`  ',
       f'**Bandas declaradas:** {cov["n_bands"]}; de {freq_name(cov["minimum_hz"])} a '
       f'{freq_name(cov["maximum_hz"])}  ',
       '**Metodología:** CF2 Analyzer & Summarizer v0.7', '',
       '## Resumen general','',ov['texto'],'',
       '## Por regiones espectrales','']
    for r in ov['regiones']: t.append('- '+r['resumen'])
    t+=['','## Panorama de todas las bandas','',
        '| Banda | DI axial | DI máx. | Ancho H/V a −6 dB | Interpretación |',
        '|---:|---:|---:|---:|---|']
    for b in bands:
        m=b['metricas'];t.append(f'| {freq_name(b["frequency_hz"])} | {show(m["di_axial_db"],2)} dB | '
                                f'{show(m["di_max_db"],2)} dB | '
                                f'{show(m["beamwidth_h_deg"])+("°" if m["beamwidth_h_deg"] is not None else "")} / '
                                f'{show(m["beamwidth_v_deg"])+("°" if m["beamwidth_v_deg"] is not None else "")} | '
                                f'{b["estado_interpretacion"]} |')
    t+=['','## Caracterización de cada banda','']
    for b in bands:
        t += [f'### {freq_name(b["frequency_hz"])}','',
              '**En pocas palabras.** '+b['resumen_breve'],'',
              '**Descripción técnica.** '+b['descripcion_tecnica'],'',
              '**Qué significa acústicamente.** '+b['interpretacion_acustica'],'']
        if b['limitaciones']:
            t.append('**Precauciones.** '+' '.join(b['limitaciones']));t.append('')
    t+=['## Glosario de interpretación','',
        '- **DI axial:** comparación energética de la radiación en el eje frontal con el promedio angular esférico.',
        '- **DI máximo:** DI calculado en la dirección de mayor nivel relativo de la malla angular.',
        '- **Beamwidth a −6 dB:** anchura del haz en cada corte donde existen los dos cruces al nivel definido.',
        '- **Cono frontal ±60°:** fracción de potencia relativa dentro de ese cono, no porcentaje de SPL de una sala.',
        '- **JSD:** distancia entre distribuciones angulares de bandas adyacentes, no prueba de calidad del altavoz.',
        '- **Candidatos a lóbulos:** máximos locales en cortes 2D; no deben confundirse con lóbulos 3D.',
        '', '## Límites y trazabilidad','',
        '- Se utilizan exclusivamente las frecuencias declaradas en el CF2; no hay muestreo 44,1/48 kHz.',
        '- Las denominaciones H/V siguen provisionales hasta validación externa de la convención angular.',
        '- Los umbrales de texto son exploratorios y no implican aptitud para una sala.',
        '- La comparación con campos EA es una comprobación interna, no evidencia de medición independiente.',
        '- El análisis no selecciona, descarta ni ordena altavoces por calidad.', '']
    return '\n'.join(t)


def write_table(path:Path, data:list[dict]):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8-sig',newline='') as file:
        if not data:return
        writer=csv.DictWriter(file,fieldnames=list(data[0].keys()))
        writer.writeheader()
        for row in data:
            writer.writerow({k:'' if v is None else v for k,v in row.items()})


def main(argv:list[str]|None=None)->int:
    cli=argparse.ArgumentParser(description='Caracteriza CF2 en palabras y metadatos (sin selección ni figuras).')
    cli.add_argument('--input',type=Path,required=True,help='corpus_metrics.csv, CF2 o directorio de CF2')
    cli.add_argument('--output',type=Path,required=True,help='directorio de informes')
    cli.add_argument('--recursive',action='store_true',help='buscar CF2 en subdirectorios')
    cli.add_argument('--limit',type=int,default=0,help='máximo de archivos CF2 en modo directorio')
    cli.add_argument('--model',type=str,default='',help='filtrar por modelo exacto sin procesar los demás perfiles')
    cli.add_argument('--config',type=Path,default=HERE/'config'/'descripcion_v07.json')
    args=cli.parse_args(argv)
    try:
        cfg=json.loads(args.config.read_text(encoding='utf-8'))
        if cfg.get('version')!=VERSION:raise ValueError('La configuración no corresponde a v0.7.0')
        source_kind='csv' if args.input.is_file() and args.input.suffix.lower()=='.csv' else 'cf2'
        if source_kind=='csv': data=baseline.read_csv(args.input)
        else: data=baseline.load_cf2(args.input,args.recursive,args.limit)
        dedup,meta=baseline.deduplicate(data)
        if args.model:
            dedup=[r for r in dedup if str(r.get('model','')).casefold()==args.model.casefold()]
        if not dedup:raise ValueError('No hay registros válidos con esos filtros.')
        grouped=defaultdict(list)
        for row in dedup:grouped[str(row['sha256'])].append(row)
        output=args.output;output.mkdir(parents=True,exist_ok=True)
        flat_bands=[];flat_speakers=[]
        for sha,rs in sorted(grouped.items(),key=lambda kv:(str(kv[1][0].get('model','')).casefold(),kv[0])):
            profile=aggregate_speaker(rs,cfg)
            profile['methodology']['rules_sha256']=hashlib.sha256(
                json.dumps(cfg,sort_keys=True,ensure_ascii=False).encode('utf-8')).hexdigest()
            identity=profile['identity']; ov=profile['overview']; cov=profile['coverage']
            folder=output/'altavoces'/f'{baseline.slug(identity["model"])}_{sha[:12]}'
            folder.mkdir(parents=True,exist_ok=True)
            (folder/'metadata.json').write_text(json.dumps(profile,ensure_ascii=False,indent=2),encoding='utf-8')
            (folder/'summary.md').write_text(markdown_report(profile),encoding='utf-8')
            single=[band_flat(identity,b) for b in profile['bands']]
            write_table(folder/'bands.csv',single)
            flat_bands.extend(single)
            flat_speakers.append({
                'sha256':sha,'model':identity['model'],'manufacturer':identity['manufacturer'],
                'filename':identity['filename'],'n_bandas':cov['n_bands'],
                'f_min_hz':cov['minimum_hz'],'f_max_hz':cov['maximum_hz'],
                'di_axial_max_db':ov['pico_di_axial_db'],
                'di_axial_max_hz':ov['frecuencia_pico_di_axial_hz'],
                'di_direccion_max_db':ov['pico_di_max_db'],
                'n_bandas_fuera_eje':ov['n_bandas_maximo_fuera_eje'],
                'n_bandas_anisotropicas_cortes':ov['n_bandas_cobertura_anisotropica_cortes'],
                'n_bandas_revisar':ov['conteo_estados'].get('revisar',0),
                'perfil_general':ov['texto'],
                'informe_relativo':str(folder.relative_to(output)/'summary.md'),
                'metadatos_relativos':str(folder.relative_to(output)/'metadata.json')})
        write_table(output/'catalogo_altavoces.csv',flat_speakers)
        write_table(output/'catalogo_bandas.csv',flat_bands)
        (output/'catalogo_altavoces.json').write_text(json.dumps(flat_speakers,ensure_ascii=False,indent=2),encoding='utf-8')
        with (output/'catalogo_bandas.jsonl').open('w',encoding='utf-8') as f:
            for band in flat_bands:f.write(json.dumps(band,ensure_ascii=False)+'\n')
        by_freq=Counter(b['frequency_hz'] for b in flat_bands)
        stats=['# Catálogo de directividad CF2 — v0.7','',
               f'- Altavoces/archivos únicos analizados: **{len(flat_speakers)}**.',
               f'- Registros de banda: **{len(flat_bands)}**.',
               f'- Filas originales del CSV: **{meta["filas_originales"]}**.',
               f'- Filas duplicadas (SHA + frecuencia): **{meta["filas_duplicadas"]}**.',
               f'- Conflictos entre duplicados: **{len(meta["conflictos_duplicados"])}**.',
               '', '## Cobertura por banda','', '| Frecuencia | Archivos |','|---:|---:|']
        for f in FREQUENCIES:stats.append(f'| {freq_name(f)} | {by_freq.get(f,0)} |')
        stats+=['','## Cómo leer este catálogo','',
                'Cada altavoz tiene `metadata.json`, `bands.csv` y `summary.md`. '
                'Cada banda incluye una descripción breve, técnica e interpretación física.',
                'Las clases son exploratorias y no expresan calidad ni idoneidad para una sala.',
                'Se conserva DI axial y DI en la dirección del máximo, además de advertencias de cobertura, orientación y JSD.',
                'No hay selección ni ranking de altavoces.','']
        (output/'resumen_corpus.md').write_text('\n'.join(stats),encoding='utf-8')
        manifest={**meta,'version_summarizer':VERSION,'entrada':str(args.input),
                  'tipo_entrada':source_kind,'modelo_filtrado':args.model or None,
                  'archivos_emitidos':len(flat_speakers),'bandas_emitidas':len(flat_bands),
                  'reglas':cfg,'notas':[
                      'Los datos v0.2/v0.3 del CSV son la fuente cuantitativa; v0.7 no los recalcula.',
                      'H/V provisionales hasta revisión con CLF Viewer.',
                      'No se recomienda ni descarta ningún altavoz.'
                  ]}
        (output/'metadatos_ejecucion.json').write_text(json.dumps(safe(manifest),ensure_ascii=False,indent=2),encoding='utf-8')
        print(f'[OK] v0.7: {len(flat_speakers)} archivos únicos, {len(flat_bands)} bandas, '\
              f'{meta["filas_duplicadas"]} registros duplicados descartados.')
        print(f'[SALIDA] {output}')
        return 0
    except (ValueError,OSError,KeyError) as e:
        print('[ERROR]',e,file=sys.stderr)
        return 2


if __name__=='__main__':
    raise SystemExit(main())
