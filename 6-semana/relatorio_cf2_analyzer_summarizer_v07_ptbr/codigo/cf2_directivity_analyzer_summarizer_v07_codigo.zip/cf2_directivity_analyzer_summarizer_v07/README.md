# CF2 Directivity Analyzer & Summarizer v0.7

Herramienta **textual y reproducible** para entender la directividad de cada altavoz y cada banda de tercio de octava presente en un CF2. **No selecciona ni descarta altavoces**; ese trabajo queda reservado para el futuro proyecto **CF2 Speaker Selector**.

## Qué se obtiene

Cada configuración/binario único (identificado por SHA-256) produce:

```text
salida/
├── catalogo_altavoces.csv
├── catalogo_altavoces.json
├── catalogo_bandas.csv
├── catalogo_bandas.jsonl
├── resumen_corpus.md
├── metadatos_ejecucion.json
└── altavoces/
    └── LA1_UW24_<12 primeros caracteres SHA>/
        ├── metadata.json   # datos numéricos + interpretación de cada banda
        ├── bands.csv       # una fila por banda con descripciones
        └── summary.md      # ficha legible, bandas, regiones y glosario
```

Cada banda genera tres campos: `resumen_breve`, `descripcion_tecnica` e `interpretacion_acustica`. Las reglas están versionadas en `config/descripcion_v07.json`. El texto se genera con reglas deterministas; no utiliza servicios de IA ni imágenes.

### Camino rápido: CSV ya calculado (recomendado)

Python 3.10+; sin NumPy, pip ni sudo.

```bash
cd cf2_directivity_analyzer_summarizer_v07
python3 cf2_describer_v07.py \
  --input "$HOME/Documentos/Juan/cf2-characterization-v03/corpus_completo/corpus_metrics.csv" \
  --output "$HOME/Documentos/Juan/cf2-summaries-v07"
```

Ajusta la ruta real con `find "$HOME/Documentos/Juan" -name corpus_metrics.csv`.

Para procesar solo un modelo **sin perder sus bandas**:

```bash
python3 cf2_describer_v07.py \
  --input /ruta/al/corpus_metrics.csv \
  --model LA1_UW24 \
  --output ./ejemplo_bosch
```

### Archivo `.CF2` directo (nuevo modelo / comprobación)

Requiere `numpy`. Reutiliza el parser v5 y las métricas de la versión anterior **sin cambiarlos**:

```bash
python3 cf2_describer_v07.py \
  --input "/ruta/a/LA1_UW24.CF2" \
  --output ./bosch_desde_cf2
```

También acepta una carpeta de CF2 con `--recursive`; no hace falta volver a calcular métricas de un corpus que ya dispone de CSV.

### Docker Desktop, modo CSV sin paquetes adicionales

```bash
docker build -f Dockerfile.csv -t cf2-summarizer:0.7-csv .

CSV_DIR="$HOME/Documentos/Juan/cf2-characterization-v03/corpus_completo"
OUT_DIR="$HOME/Documentos/Juan/cf2-summaries-v07"
mkdir -p "$OUT_DIR"

docker run --rm \
  -v "$CSV_DIR:/input:ro" \
  -v "$OUT_DIR:/out" \
  cf2-summarizer:0.7-csv \
  --input /input/corpus_metrics.csv \
  --output /out
```

Para CF2 originales, `docker build -f Dockerfile.cf2 -t cf2-summarizer:0.7-cf2 .` y pasa `--input /cf2/...` con el volumen que contiene tus CF2. **La construcción Docker aún no se ha verificado en el equipo del usuario.**

## Reglas que sí respeta el análisis

- Frecuencias: **solo las bandas declaradas en el CF2**, dentro de la tabla estándar de 30 centros entre 25 y 20.000 Hz. No interpolar las que falten.
- DI axial y DI máximo se mantienen separados; el segundo solo implica concentración en la dirección del máximo de la malla angular.
- Un haz fuera del eje no se clasifica como defecto. Los anchos a −6 dB referidos al eje frontal podrían no describir su haz principal.
- `n/d` para ancho de haz no significa 360°, cero ni fichero corrupto.
- La orientación de los cortes H/V es **provisional** mientras falte una comprobación independiente con CLF Viewer.
- Los porcentajes de energía describen **distribución angular de potencia relativa**, no SPL absoluto.
- Los candidatos a lóbulos secundarios son máximos locales de cortes 2D, **no lóbulos espaciales 3D confirmados**.
- JSD entre frecuencias se interpreta solo cuando son **bandas contiguas** y el valor procede realmente de esa pareja. JSD elevada significa cambio espacial, no mala calidad.
- Las categorías «poco/moderadamente/muy directivo» se basan en **umbrales exploratorios editables**, no normas de calidad.
- Los campos EA permiten una **autocomprobación interna**; no constituyen validación externa de la directividad.
- No se calcula idoneidad para una sala, no se recomienda ni se descarta ningún altavoz.

## Metadatos y reutilización

`metadata.json` incluye `schema_version`, `identity`, `coverage`, `overview`, `methodology`, y una lista `bands` con métricas, etiquetas descriptivas, las tres explicaciones, transiciones contiguas y limitaciones. La identidad incluye nombre, fabricante, archivo y SHA-256. En el catálogo completo se evita contar copias binarias idénticas como modelos adicionales.

## Pruebas

```bash
python3 -m unittest discover -s tests -v
```

Las 23 pruebas incluyen regresiones heredadas de v0.6 y casos de la v0.7. Además se procesó el binario real Bosch LA1_UW24: los 21 valores de DI axial coincidieron numéricamente con el CSV previo.

## Carpeta de implementación

- `cf2_describer_v07.py`: nuevo motor textual y de metadatos.
- `cf2_summarizer.py`: lógica heredada y no alterada de lectura, deduplicación y extracción CF2 de v0.6.
- `cf2_parser_v5.py`, `cf2_directivity_metrics.py`, `cf2_pattern_metrics.py`: lectura y métricas originales.
- `config/descripcion_v07.json`: reglas textuales v0.7.
- `config/criterios_v06.json`: configuración heredada para las pruebas y compatibilidad de v0.6.
- `tests/`: comprobaciones automatizadas.

El selector futuro consumirá estos metadatos sin alterar las descripciones de v0.7.
