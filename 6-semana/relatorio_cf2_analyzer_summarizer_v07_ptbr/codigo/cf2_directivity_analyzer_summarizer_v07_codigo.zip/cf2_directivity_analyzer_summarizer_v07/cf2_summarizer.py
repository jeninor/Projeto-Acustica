#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CF2 Directivity Summarizer 0.6 — reproducible, text-only analysis.

Two input modes:
  - precomputed corpus_metrics.csv (stdlib only)
  - original .CF2 or directory (requires numpy; reuses immutable parser v5
    and numerical methods v0.2; does not generate images)

Scientific cautions: axial DI != peak-direction DI; H/V conventions remain
provisional; JSD is not a certified quality/stability metric.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
CF2_FREQS = (25,31.5,40,50,63,80,100,125,160,200,250,315,400,500,630,800,
             1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000)
REQUIRED = ('sha256', 'manufacturer', 'model', 'frequency_hz',
            'di_integrated_db', 'peak_off_axis_db')
VERSION = '0.6.0'


def num(v: Any) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else math.nan
    except (ValueError, TypeError, OverflowError):
        return math.nan


def val(row: dict, key: str) -> float:
    return num(row.get(key))


def fmt(v: float, d: int=1) -> str:
    return f'{v:.{d}f}' if math.isfinite(v) else 'n/d'


def frequency_name(f: float) -> str:
    return ((f'{int(f):,}'.replace(',', '.') if float(f).is_integer() else f'{f:g}'.replace('.', ',')) + ' Hz')


def load_cfg(custom: Path | None = None) -> dict:
    p = custom or HERE / 'config' / 'criterios_v06.json'
    cfg = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(cfg, dict) or cfg.get('version') != VERSION:
        raise ValueError('Configuración ausente o de versión incompatible (esperada 0.6.0).')
    return cfg


def read_csv(path: Path) -> list[dict]:
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open(newline='', encoding='utf-8-sig') as f:
        r = csv.DictReader(f)
        missing = set(REQUIRED).difference(r.fieldnames or [])
        if missing:
            raise ValueError('Columnas requeridas no encontradas: '+', '.join(sorted(missing)))
        rows = list(r)
    return rows


def is_known_frequency(f: float) -> bool:
    return any(abs(f-allowed) < 1e-4 for allowed in CF2_FREQS)


def deduplicate(rows: list[dict]) -> tuple[list[dict],dict]:
    seen = {}; collisions = []; invalid = []; duplicates = 0
    hashes = set()
    for i, row in enumerate(rows, start=2):
        sha = str(row.get('sha256','')).strip().lower()
        f = val(row, 'frequency_hz')
        if not re.fullmatch(r'[a-f0-9]{64}', sha) or not is_known_frequency(f):
            invalid.append({'linea_csv': i, 'sha256': sha, 'frecuencia_hz': str(row.get('frequency_hz'))})
            continue
        hashes.add(sha)
        key = (sha, f)
        if key in seen:
            duplicates += 1
            old = seen[key]
            for field in ('di_integrated_db','peak_off_axis_db','h_width_deg','v_width_deg'):
                x,y = val(old,field),val(row,field)
                if (math.isfinite(x) != math.isfinite(y)) or (math.isfinite(x) and abs(x-y)>0.001):
                    collisions.append({'sha256':sha, 'frequency_hz':f,'campo':field,
                                       'primero': fmt(x,5), 'duplicado':fmt(y,5)})
        else:
            seen[key] = dict(row)
    result = sorted(seen.values(), key=lambda r:(r['sha256'], val(r,'frequency_hz')))
    return result, {'filas_originales':len(rows), 'registros_unicos':len(result),
                    'archivos_unicos':len({r['sha256'] for r in result}),
                    'filas_duplicadas':duplicates, 'filas_invalidas':invalid,
                    'conflictos_duplicados':collisions}


def category(di: float, cfg: dict) -> str:
    if not math.isfinite(di): return 'no determinado'
    if di < 0: return 'DI negativo respecto a ese eje'
    a,b,c = cfg['di_categories_db']
    if di < a: return 'poco directivo'
    if di < b: return 'moderadamente directivo'
    if di < c: return 'directivo'
    return 'muy directivo'


def width_category(w: float, cfg: dict) -> str:
    if not math.isfinite(w): return 'no delimitada a −6 dB'
    a,b,c = cfg['width_categories_deg']
    if w < a: return 'estrecha'
    if w < b: return 'intermedia'
    if w < c: return 'amplia'
    return 'muy amplia'


def describe_concentration(p: float, cfg: dict) -> str:
    a,b,c = cfg['front_cone_60_pct_thresholds']
    if not math.isfinite(p): return 'concentración frontal no determinada'
    if p < a: return 'poca potencia relativa dentro del cono frontal de ±60°'
    if p < b: return 'concentración frontal moderada dentro de ±60°'
    if p < c: return 'predominio de potencia relativa en el cono frontal de ±60°'
    return 'alta concentración de potencia relativa en el cono frontal de ±60°'


def data_quality(r: dict, cfg: dict, did:float, delta:float) -> tuple[str,list[str]]:
    issues=[]; serious=False
    for fld in ('di_integrated_db','q_integrated'):
        if not math.isfinite(val(r,fld)):
            issues.append(f'{fld} ausente/no finito');serious=True
    if str(r.get('quality_status','')).strip().lower() == 'invalid':
        issues.append('indicador de datos inválidos del analizador');serious=True
    qerr = val(r,'ea_q_relative_error_pct')
    if math.isfinite(qerr) and qerr > cfg['ea_q_discrepancy_review_pct']:
        issues.append('diferencia con Q del campo EA superior al umbral de revisión');serious=True
    for fld in ('ea_h_width_error_abs_deg','ea_v_width_error_abs_deg'):
        e=val(r,fld)
        if math.isfinite(e) and e>cfg['ea_width_discrepancy_review_deg']:
            issues.append('diferencia de ancho de haz frente a EA superior al umbral');serious=True
    if serious: return 'revisar',list(dict.fromkeys(issues))
    if not (math.isfinite(val(r,'h_width_deg')) and math.isfinite(val(r,'v_width_deg'))):
        issues.append('cobertura H/V no delimitada completamente a −6 dB')
    if delta>cfg['off_axis_level_warning_db']:
        issues.append('ancho referido al eje frontal: no caracteriza necesariamente el haz principal')
    for fld in ('h_width_deg','v_width_deg'):
        w=val(r,fld)
        if math.isfinite(w) and w<=cfg['narrow_width_resolution_warning_deg']:
            issues.append('ancho cercano a la resolución angular de 5°')
            break
    if str(r.get('quality_flags','')).lower().find('inconsistent_poles')>=0:
        issues.append('consistencia de polos angular pendiente de revisión')
    return ('limitado' if issues else 'válido'), list(dict.fromkeys(issues))


def previous_adjacent_band(curr: float, prev: float) -> bool:
    if not (math.isfinite(curr) and math.isfinite(prev)): return False
    try:
        return CF2_FREQS.index(curr)-CF2_FREQS.index(prev)==1
    except ValueError:
        return False


def enrich_row(r: dict, cfg:dict) -> dict:
    f = val(r,'frequency_hz'); di = val(r,'di_integrated_db')
    delta = val(r,'peak_off_axis_db'); peak_di = di+delta if math.isfinite(di) and math.isfinite(delta) else math.nan
    h,v = val(r,'h_width_deg'), val(r,'v_width_deg')
    rear=val(r,'rear_power_pct'); front60=val(r,'front_cone_60_power_pct')
    offaxis = math.isfinite(delta) and delta>cfg['off_axis_level_warning_db']
    state,issues = data_quality(r,cfg,di,delta)
    pieces = [f'DI axial {fmt(di,2)} dB ({category(di,cfg)})']
    if math.isfinite(peak_di):
        pieces.append(f'DI en la dirección del máximo {fmt(peak_di,2)} dB ({category(peak_di,cfg)})')
    if offaxis:
        arc=val(r,'peak_arc_deg')
        pieces.append(f'máximo de nivel {fmt(delta,1)} dB por encima del eje frontal'+
                      (f' a {fmt(arc,0)}° de ese eje' if math.isfinite(arc) else '')+
                      '; el DI axial no representa el máximo direccional')
    else:
        pieces.append('el máximo de nivel no supera el eje frontal en más de 3 dB, según el criterio descriptivo')
    if math.isfinite(h) or math.isfinite(v):
        pieces.append(f'cobertura estimada a −6 dB: H {fmt(h) + chr(176) if math.isfinite(h) else 'n/d'} ({width_category(h,cfg)}), '+
                      f'V {fmt(v) + chr(176) if math.isfinite(v) else 'n/d'} ({width_category(v,cfg)}), con orientación H/V aún provisional')
    else:
        pieces.append('coberturas axial H/V no delimitadas completamente a −6 dB')
    if math.isfinite(h) and math.isfinite(v) and min(h,v)>0 and not offaxis:
        ratio=max(h,v)/min(h,v)
        if ratio>=cfg['asymmetry_ratio_warning']:
            pieces.append('cobertura más extensa en el corte '+('H' if h>v else 'V')+ ' que en el otro corte')
    if math.isfinite(front60): pieces.append(describe_concentration(front60,cfg)+f' ({fmt(front60)} %)')
    if math.isfinite(rear):
        rear_kind = ('fracción posterior reducida' if rear<cfg['rear_pct_thresholds'][0]
                     else 'fracción posterior apreciable' if rear >= cfg['rear_pct_thresholds'][1]
                     else 'fracción posterior intermedia')
        pieces.append(f'{rear_kind} ({fmt(rear)} % de potencia angular relativa)')
    prev=val(r,'previous_frequency_hz')
    adjacent=previous_adjacent_band(f,prev)
    jsd=val(r,'pattern_jsd_vs_previous_bits')
    ddi=val(r,'di_change_vs_previous_db')
    if adjacent and math.isfinite(jsd) and jsd>=cfg['jsd_adjacent_change_note_bits']:
        pieces.append(f'cambio importante en la distribución angular frente a {frequency_name(prev)} '
                      f'(JSD {fmt(jsd,3)} bits, umbral exploratorio)')
    if adjacent and math.isfinite(ddi) and abs(ddi)>=cfg['di_adjacent_change_note_db']:
        pieces.append(f'variación de DI axial {fmt(ddi,2)} dB respecto a la banda anterior')
    if issues:
        pieces.append('Limitaciones: '+ '; '.join(issues))
    return {**r, 'di_max_db_v06':peak_di, 'clase_di_axial_v06':category(di,cfg),
            'clase_di_max_v06':category(peak_di,cfg), 'estado_v06':state,
            'observaciones_v06':'; '.join(issues), 'banda_previa_contigua_v06':adjacent,
            'descripcion_v06':'. '.join(p[0].upper()+p[1:] if p else p for p in pieces)+'.'}


def spectral_group(f:float,cfg:dict) -> str:
    return 'bajas' if f<=cfg['low_band_upper_hz'] else ('medias' if f<=cfg['mid_band_upper_hz'] else 'altas')


def speaker_summary(rows:list[dict], cfg:dict) -> dict:
    rs=sorted(rows,key=lambda r:val(r,'frequency_hz'))
    first=rs[0]; freqs=[val(r,'frequency_hz') for r in rs]
    usable_axial=[r for r in rs if math.isfinite(val(r,'di_integrated_db'))]
    peak_axial=max(usable_axial,key=lambda r:val(r,'di_integrated_db')) if usable_axial else None
    usable_max=[r for r in rs if math.isfinite(val(r,'di_max_db_v06'))]
    peak_max=max(usable_max,key=lambda r:val(r,'di_max_db_v06')) if usable_max else None
    group_lines=[]
    for group,range_text in [('bajas','25–250 Hz'),('medias','315–2.000 Hz'),('altas','2.500–20.000 Hz')]:
        g=[r for r in rs if spectral_group(val(r,'frequency_hz'),cfg)==group]
        if not g:
            group_lines.append(f'No hay bandas declaradas en el tramo {group} ({range_text}).')
            continue
        good=[r for r in g if math.isfinite(val(r,'di_max_db_v06'))]
        if good:
            vals=sorted(val(r,'di_max_db_v06') for r in good)
            med=vals[len(vals)//2] if len(vals)%2 else (vals[len(vals)//2-1]+vals[len(vals)//2])/2
            group_lines.append(f'En las frecuencias {group} ({range_text}, {len(g)} bandas), '+
                               f'la mediana de DI en la dirección del máximo es {fmt(med,2)} dB; '+
                               f'esto describe únicamente las frecuencias disponibles del modelo.')
    jsd_candidates=[r for r in rs if r['banda_previa_contigua_v06'] and
                    math.isfinite(val(r,'pattern_jsd_vs_previous_bits'))]
    jsd_max=max(jsd_candidates,key=lambda r:val(r,'pattern_jsd_vs_previous_bits')) if jsd_candidates else None
    shifted=[r for r in rs if math.isfinite(val(r,'peak_off_axis_db')) and
             val(r,'peak_off_axis_db')>cfg['off_axis_level_warning_db']]
    limited=sum(r['estado_v06']=='limitado' for r in rs)
    reviews=sum(r['estado_v06']=='revisar' for r in rs)
    phr=[f'Se analizaron {len(rs)} bandas de tercio de octava entre '
         f'{frequency_name(freqs[0])} y {frequency_name(freqs[-1])}, sin completar bandas ausentes.']
    if peak_axial:
        phr.append(f'El mayor DI axial registrado es {fmt(val(peak_axial,"di_integrated_db"),2)} dB '
                   f'a {frequency_name(val(peak_axial,"frequency_hz"))}.')
    if peak_max:
        phr.append(f'El mayor DI en la dirección de máxima radiación alcanza '
                   f'{fmt(val(peak_max,"di_max_db_v06"),2)} dB a {frequency_name(val(peak_max,"frequency_hz"))}.')
    phr.extend(group_lines)
    # Compare only actual first/last observed bands, never infer missing bands.
    if len(usable_max)>=2:
        change=val(usable_max[-1],'di_max_db_v06')-val(usable_max[0],'di_max_db_v06')
        if abs(change)>=cfg['di_adjacent_change_note_db']:
            phr.append('Entre la primera y la última banda disponibles, el DI en dirección del máximo '
                       + ('aumenta ' if change>0 else 'disminuye ')
                       + f'{fmt(abs(change),2)} dB; esto no implica una evolución monótona.')
    comparable_hv=[r for r in rs if math.isfinite(val(r,'h_width_deg'))
                   and math.isfinite(val(r,'v_width_deg'))
                   and val(r,'peak_off_axis_db')<=cfg['off_axis_level_warning_db']]
    if comparable_hv:
        h_wider=sum(val(r,'h_width_deg')>val(r,'v_width_deg') for r in comparable_hv)
        v_wider=sum(val(r,'h_width_deg')<val(r,'v_width_deg') for r in comparable_hv)
        if h_wider>=max(2,int(len(comparable_hv)*0.7)):
            phr.append(f'En {h_wider} de {len(comparable_hv)} bandas con coberturas axiales medibles, '
                       'el corte H es más ancho que el V (denominaciones provisionales).')
        elif v_wider>=max(2,int(len(comparable_hv)*0.7)):
            phr.append(f'En {v_wider} de {len(comparable_hv)} bandas con coberturas axiales medibles, '
                       'el corte V es más ancho que el H (denominaciones provisionales).')
    if shifted: phr.append(f'En {len(shifted)} '+('banda' if len(shifted)==1 else 'bandas')+' el máximo supera al nivel axial en más de '
                           f'{fmt(cfg["off_axis_level_warning_db"],0)} dB; '
                           'se debe interpretar la orientación del haz por separado.')
    if jsd_max:
        phr.append('El mayor cambio de distribución espacial entre bandas consecutivas ocurre '+
                   f'de {frequency_name(val(jsd_max,"previous_frequency_hz"))} a '
                   f'{frequency_name(val(jsd_max,"frequency_hz"))} '
                   f'(JSD {fmt(val(jsd_max,"pattern_jsd_vs_previous_bits"),3)} bits). '+
                   'Este indicador no demuestra por sí solo un defecto o inestabilidad perjudicial.')
    if limited or reviews:
        phr.append(f'Hay {limited} bandas con mediciones limitadas y {reviews} que requieren revisión; '
                   'las etiquetas H/V son provisionales.')
    return {'sha256':first['sha256'], 'model':str(first.get('model','')), 'manufacturer':str(first.get('manufacturer','')),
            'filename':str(first.get('filename','')), 'n_bandas':len(rs),'f_min_hz':freqs[0],
            'f_max_hz':freqs[-1], 'di_axial_pico_db': val(peak_axial,'di_integrated_db') if peak_axial else math.nan,
            'di_axial_pico_hz': val(peak_axial,'frequency_hz') if peak_axial else math.nan,
            'di_max_pico_db':val(peak_max,'di_max_db_v06') if peak_max else math.nan,
            'di_max_pico_hz':val(peak_max,'frequency_hz') if peak_max else math.nan,
            'bandas_fuera_eje':len(shifted),'bandas_limitadas':limited,'bandas_revisar':reviews,
            'jsd_max_consecutiva_bits':val(jsd_max,'pattern_jsd_vs_previous_bits') if jsd_max else math.nan,
            'descripcion_general_v06':' '.join(phr)}


def write_csv(path:Path,rows:list[dict]):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:
        path.write_text('', encoding='utf-8')
        return
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader()
        for row in rows:
            w.writerow({k:(fmt(v,8) if isinstance(v,float) and not math.isfinite(v) else v)
                        for k,v in row.items()})


def safe_json(v):
    if isinstance(v, dict):return {k:safe_json(x) for k,x in v.items()}
    if isinstance(v, list):return [safe_json(x) for x in v]
    if isinstance(v, float):return v if math.isfinite(v) else None
    return v


def slug(value:str)->str:
    v=re.sub(r'[^A-Za-z0-9_-]+','_',value).strip('_')
    return v[:56] or 'modelo'


def render_speaker(s:dict,rows:list[dict]) -> str:
    text=[f'# Caracterización de directividad — {s["model"]}', '',
          f'**Fabricante:** {s["manufacturer"]}  ',f'**Archivo:** `{s["filename"]}`  ',
          f'**SHA-256:** `{s["sha256"]}`  ',
          f'**Bandas:** {s["n_bandas"]}, de {frequency_name(s["f_min_hz"])} a {frequency_name(s["f_max_hz"])}  ',
          '**Metodología descriptiva:** 0.6.0; resultados numéricos conservados de v0.2/v0.3 o recalculados con sus métodos.',
          '', '## Resumen general', '',s['descripcion_general_v06'],'',
          '## Descripción de todas las bandas disponibles', '',
          '| Frecuencia | DI axial (dB) | DI máximo (dB) | Cobertura H/V (°) | Estado |',
          '|---:|---:|---:|---:|---|']
    for r in sorted(rows,key=lambda r:val(r,'frequency_hz')):
        text.append(f'| {frequency_name(val(r,"frequency_hz"))} | {fmt(val(r,"di_integrated_db"),2)} | '
                    f'{fmt(val(r,"di_max_db_v06"),2)} | {fmt(val(r,"h_width_deg"))} / '
                    f'{fmt(val(r,"v_width_deg"))} | {r["estado_v06"]} |')
    text += ['','## Interpretación banda por banda','']
    for r in sorted(rows,key=lambda r:val(r,'frequency_hz')):
        text += [f'### {frequency_name(val(r,"frequency_hz"))}', '',r['descripcion_v06'],'']
    text += ['## Alcance y restricciones', '',
             '- Todas las frecuencias corresponden a centros de tercio de octava declarados; no se remuestrea audio ni se interpolan bandas ausentes.',
             '- Las clases DI y umbrales de cambio son reglas descriptivas exploratorias, no estándares de calidad.',
             '- H/V son denominaciones **provisionales** de cortes angulares del CF2; debe comprobarse su correspondencia en CLF Viewer.',
             '- DI axial y DI en dirección máxima pueden divergir en altavoces orientados fuera del eje.',
             '- Los anchos a −6 dB no delimitados no son equivalentes a un ancho de 360° ni a un error de lectura.',
             '- La malla angular CF2 tiene pasos de 5°: anchos interpolados próximos a esta escala tienen incertidumbre.',
             '- JSD cuantifica cambios en la distribución angular entre bandas contiguas, no calidad acústica ni STI.',
             '- Los valores EA permiten autoconsistencia dentro del mismo archivo, no son validación experimental independiente.',
             '- Los porcentajes frontales/posteriores describen potencia angular relativa, no SPL ni potencia absoluta en una sala.',
             '- No se generan figuras ni se modifica ningún archivo CF2.', '']
    return '\n'.join(text)


def render_corpus(summaries:list[dict],rows:list[dict],meta:dict)->str:
    by_freq=defaultdict(list)
    for r in rows: by_freq[val(r,'frequency_hz')].append(r)
    text=['# Resumen textual del corpus CF2 — v0.6','',
          '## Cobertura y deduplicación','',
          f'- Filas leídas: **{meta["filas_originales"]}**.',
          f'- Bandas únicas por SHA-256 + frecuencia: **{meta["registros_unicos"]}**.',
          f'- Archivos binarios únicos: **{meta["archivos_unicos"]}**.',
          f'- Registros duplicados eliminados: **{meta["filas_duplicadas"]}**.',
          f'- Conflictos entre registros duplicados: **{len(meta["conflictos_duplicados"])}**.',
          f'- Filas con identificador o frecuencia inválidos: **{len(meta["filas_invalidas"])}**.',
          '', '## Disponibilidad por frecuencia', '',
          '| Frecuencia | Archivos únicos | DI axial mediana (dB) | DI máximo mediana (dB) |',
          '|---:|---:|---:|---:|']
    from statistics import median
    for f in CF2_FREQS:
        g=by_freq.get(f,[])
        ax=[val(r,'di_integrated_db') for r in g if math.isfinite(val(r,'di_integrated_db'))]
        maximum=[val(r,'di_max_db_v06') for r in g if math.isfinite(val(r,'di_max_db_v06'))]
        text.append(f'| {frequency_name(f)} | {len(g)} | '
                    f'{fmt(median(ax),2) if ax else "n/d"} | '
                    f'{fmt(median(maximum),2) if maximum else "n/d"} |')
    c=Counter(r['estado_v06'] for r in rows)
    text += ['', '## Fiabilidad de las descripciones', '',
             f'- Bandas válidas: **{c["válido"]}**.',
             f'- Bandas con cobertura/interpretación limitada: **{c["limitado"]}**.',
             f'- Bandas a revisar por métricas ausentes/inconsistencia EA: **{c["revisar"]}**.',
             '', '## Precauciones de comparación', '',
             'Comparar altavoces en la **misma frecuencia**. Las medianas por banda no cubren exactamente los mismos modelos;',
             'por tanto no deben interpretarse como el comportamiento longitudinal de una cohorte fija.',
             'No se consideran mejores los altavoces por tener más DI o menos JSD sin definir el caso de uso.',
             'No se produce un ranking basado en promedios de frecuencias incompatibles.',
             'Los cortes H/V y los umbrales de clasificación continúan siendo provisionales.',
             '', '## Archivos emitidos', '',
             '- `catalogo_bandas.csv`: cada banda y su descripción.',
             '- `catalogo_altavoces.csv` y `.json`: descripción general de cada CF2 único.',
             '- `catalogo_bandas.jsonl`: descripción JSON estructurada, una línea por banda.',
             '- `altavoces/`: informes Markdown individuales por SHA-256.',
             '- `metadatos.json`: recuentos, configuración y trazabilidad.', '']
    return '\n'.join(text)


def load_cf2(path: Path, recursive:bool, limit:int) -> list[dict]:
    """Reuse numerical functions without importing plotting modules."""
    import numpy as np
    from cf2_parser_v5 import CF2File
    from cf2_directivity_metrics import measure_directivity
    from cf2_pattern_metrics import pattern_metrics,ea_consistency_metrics,attach_spectral_differences
    paths=([path] if path.is_file() else sorted(
        p for p in (path.rglob('*') if recursive else path.glob('*'))
        if p.is_file() and p.suffix.casefold()=='.cf2'))
    if path.is_file() and path.suffix.lower()!='.cf2': raise ValueError('Se esperaba archivo .CF2.')
    if limit>0: paths=paths[:limit]
    if not paths: raise ValueError('No se encontraron CF2.')
    all_rows=[]
    for file in paths:
        cf2=CF2File(file)
        structure=cf2.structure_report()
        if structure.get('status')!='PASS':
            raise ValueError(f'CF2 estructura no válida: {file}: {structure}')
        freqs=cf2.declared_frequencies
        digest=hashlib.sha256(cf2.raw).hexdigest()
        common={'file':str(file),'filename':file.name,'sha256':digest,
                'manufacturer':str(cf2.metadata.get('manufacturer','')),
                'model':str(cf2.metadata.get('model_name') or file.stem),
                'methodology_version':'0.2.0', 'frequency_count':len(freqs)}
        rows=[];surfaces={}
        for frequency in freqs:
            f=float(frequency)
            surface=cf2.directivity_third_octave(f)
            surfaces[f]=surface
            m=measure_directivity(surface,f,ea=cf2.ea_value(f))
            rows.append({**common,**m,**pattern_metrics(surface,m),**ea_consistency_metrics(m)})
        attach_spectral_differences(rows,surfaces)
        all_rows.extend(rows)
        print(f'[CF2] {file.name}: {len(rows)} bandas',flush=True)
    return all_rows


def run(rows:list[dict], output:Path,cfg:dict, *, input_name:str='CSV') -> dict:
    unique,meta=deduplicate(rows)
    if not unique: raise ValueError('No hay bandas CF2 válidas para resumir.')
    grouped=defaultdict(list)
    detailed=[]
    for row in unique:
        enriched=enrich_row(row,cfg)
        grouped[row['sha256']].append(enriched)
        detailed.append(enriched)
    summaries=[]
    out_sp=output/'altavoces';out_sp.mkdir(parents=True,exist_ok=True)
    for sha, speaker_rows in sorted(grouped.items(),key=lambda kv:(str(kv[1][0].get('model','')).casefold(),kv[0])):
        s=speaker_summary(speaker_rows,cfg)
        summaries.append(s)
        output_name=f'{slug(s["model"])}_{sha[:12]}.md'
        (out_sp/output_name).write_text(render_speaker(s,speaker_rows),encoding='utf-8')
        s['informe_relativo']='altavoces/'+output_name
    output.mkdir(parents=True,exist_ok=True)
    write_csv(output/'catalogo_bandas.csv',detailed)
    write_csv(output/'catalogo_altavoces.csv',summaries)
    (output/'catalogo_altavoces.json').write_text(
        json.dumps(safe_json(summaries),ensure_ascii=False,indent=2),encoding='utf-8')
    with (output/'catalogo_bandas.jsonl').open('w',encoding='utf-8') as dst:
        for r in detailed:
            keep={
                'sha256':r['sha256'],'modelo':r.get('model',''),
                'frecuencia_hz':val(r,'frequency_hz'),
                'di_axial_db':val(r,'di_integrated_db'),
                'di_max_db':val(r,'di_max_db_v06'),
                'clase_axial':r['clase_di_axial_v06'],
                'clase_max':r['clase_di_max_v06'],
                'estado':r['estado_v06'],
                'descripcion':r['descripcion_v06']
            }
            dst.write(json.dumps(safe_json(keep),ensure_ascii=False)+'\n')
    (output/'resumen_corpus.md').write_text(render_corpus(summaries,detailed,meta),encoding='utf-8')
    meta.update({'version_summarizer':VERSION,'entrada':input_name,'frecuencias_posibles_hz':list(CF2_FREQS),
                 'frecuencias_observadas_hz':sorted({val(r,'frequency_hz') for r in detailed}),
                 'config_criterios':cfg,'reglas_hv_provisionales':True,
                 'recalculo_acustico':input_name!='CSV'})
    (output/'metadatos.json').write_text(json.dumps(safe_json(meta),ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'[OK] {meta["archivos_unicos"]} altavoces, {len(detailed)} bandas, {meta["filas_duplicadas"]} duplicados descartados')
    print(f'[SALIDA] {output}')
    return meta


def main(argv:list[str]|None=None) -> int:
    ap=argparse.ArgumentParser(description='Genera descripciones TEXTUALES de directividad CF2; no dibuja figuras.')
    ap.add_argument('--input',required=True,type=Path,help='corpus_metrics.csv, un CF2 o directorio de CF2')
    ap.add_argument('--output',required=True,type=Path,help='carpeta de informes')
    ap.add_argument('--recursive',action='store_true',help='buscar archivos CF2 en subdirectorios')
    ap.add_argument('--limit',type=int,default=0,help='limitar cantidad de archivos CF2 (0=todos)')
    ap.add_argument('--config',type=Path,help='JSON con umbrales descriptivos v0.6')
    args=ap.parse_args(argv)
    try:
        cfg=load_cfg(args.config)
        if args.input.is_file() and args.input.suffix.lower()=='.csv':
            rows=read_csv(args.input);kind='CSV'
        else:
            rows=load_cf2(args.input,args.recursive,args.limit);kind='CF2'
        run(rows,args.output,cfg,input_name=kind)
        return 0
    except (OSError,ValueError,KeyError) as exc:
        print(f'[ERROR] {exc}',file=sys.stderr)
        return 2


if __name__=='__main__':
    sys.exit(main())
