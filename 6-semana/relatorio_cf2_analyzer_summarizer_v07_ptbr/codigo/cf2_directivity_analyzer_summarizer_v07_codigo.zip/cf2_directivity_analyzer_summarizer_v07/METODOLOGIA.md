# Nota metodológica — CF2 Analyzer & Summarizer v0.7

## Propósito

Describir magnitud de directividad, geometría de cortes, orientación y evolución espectral por banda de tercio de octava. No simular presión en sala, no elegir altavoces y no emitir juicios de calidad.

## Entradas cuantitativas

La entrada CSV proviene de etapas previas del proyecto, con índices de directividad derivados de integración sobre la esfera. `cf2_describer_v07.py` interpreta estas métricas; **no vuelve a calcular ni revalida externamente la directividad** al recibir CSV. Con archivos CF2 originales invoca el parser v5 y la implementación numérica v0.2, conservadas como módulos separados.

## Reglas

- Umbrales de DI axial: `<3`, `[3,6)`, `[6,10)`, `>=10` dB (exploratorios).
- DI en la dirección máxima: `DI_axial + peak_off_axis_db`; esta diferencia se refiere a la relación nivel máximo/eje frontal informada por el análisis angular.
- Ancho H/V: cortes a −6 dB referidos al eje frontal, no medición universal de apertura 3D. Etiquetas H/V provisionales.
- Coberturas diferentes: `max(BW_H,BW_V)/min(BW_H,BW_V) >= 1.8`, con ambos valores finitos y >0.
- Máximo relevante fuera del eje: el nivel del máximo angular supera al axial en más de 3 dB.
- Fracción frontal alta: >=70 % de potencia angular relativa dentro del cono de ±60°.
- Fracción posterior reducida: <=20 % de potencia angular relativa en el hemisferio posterior.
- JSD: solo se comenta entre bandas CF2 contiguas con pareja fuente coherente; >=0.10 bits activa descripción de cambio espacial pronunciado.
- Cambio de DI adyacente >=3 dB en valor absoluto: se destaca en la interpretación; no equivale a fluctuación de SPL en sala.
- Los umbrales EA de revisión indican posibles anomalías internas. `interpretable` no significa validación H/V contra CLF Viewer.

## Limitaciones y dependencias

- Las 30 frecuencias centrales son posibilidades del formato; solo se usan las presentes en cada archivo.
- Los promedios de DI entre modelos solo tienen sentido con comparabilidad espectral explícita.
- Una JSD alta o un haz desplazado no demuestra baja calidad.
- El selector de altavoces es un proyecto posterior, con criterios de la sala y del experimento; v0.7 **no produce rankings**.
- Las imágenes de CLF Viewer siguen siendo valiosas para validar la correspondencia H/V, pero no se necesitan para generar los textos.

## Trazabilidad

Se conservan `sha256`, nombre del archivo y frecuencia. Cada perfil registra la versión del motor y hash SHA-256 del JSON de reglas. Los datos derivados pueden exportarse a CSV/JSON para otros programas y a Markdown para documentación del TCC.
