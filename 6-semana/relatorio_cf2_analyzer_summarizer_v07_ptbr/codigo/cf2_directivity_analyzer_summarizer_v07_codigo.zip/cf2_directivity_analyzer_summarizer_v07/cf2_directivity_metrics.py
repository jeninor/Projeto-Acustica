#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CF2 directivity characterization v0.1; does not modify CF2 data.

Angular assumption (MUST be checked against CLF Viewer before claiming
'left/right/up/down'): 'arc' is polar angle measured from the front axis.
For provisional vertical cuts use azimuth 0/180; horizontal 90/270.
"""
from __future__ import annotations

import math
from typing import Any, Dict, Optional, Tuple

import numpy as np

from cf2_parser_v5 import ARC_DEGREES, AZIMUTH_DEGREES

METHODOLOGY_VERSION = "0.2.0"
AXIS_SPREAD_LIMIT_DB = 1.0
OFF_AXIS_WARNING_DB = 3.0
DB_BEAMWIDTH = -6.0
# Positive-angle azimuth / negative-angle azimuth. These labels are provisional.
CUT_AZIMUTHS = {"H": (90, 270), "V": (0, 180)}


def classify_di(di_db: float, peak_off_axis_db: float = 0.0, *, reliable: bool = True) -> str:
    """Exploratory labels, NOT industry standards or product certifications."""
    if not reliable or not np.isfinite(di_db):
        return "indeterminada"
    if peak_off_axis_db > OFF_AXIS_WARNING_DB or di_db < 0:
        return "fuera_de_eje_revisar"
    if di_db < 3:
        return "poco_directivo"
    if di_db < 6:
        return "moderadamente_directivo"
    if di_db < 10:
        return "directivo"
    return "muy_directivo"


def angular_weights() -> Tuple[np.ndarray, np.ndarray]:
    """Per-arc cell solid angle weights, summed over full sphere = 1.

    Each polar sample owns the cell halfway to its neighbors. The polar
    caps end at 0/180. 72 equally spaced azimuth rows each own 1/72 of
    the full circle. Returned rear weights integrate 90..180 degrees.
    """
    theta = np.deg2rad(ARC_DEGREES.astype(float))
    edges = np.empty(theta.size + 1, dtype=float)
    edges[0], edges[-1] = 0.0, np.pi
    edges[1:-1] = (theta[:-1] + theta[1:]) / 2.0
    total = (np.cos(edges[:-1]) - np.cos(edges[1:])) / 2.0
    lower_rear = np.maximum(edges[:-1], np.pi / 2)
    rear = np.where(edges[1:] > np.pi / 2,
                    (np.cos(lower_rear) - np.cos(edges[1:])) / 2.0, 0)
    return total, rear


def angle_plane_cut(db: np.ndarray, plane: str, *, axis_reference_db: Optional[float] = None
                    ) -> Tuple[np.ndarray, np.ndarray]:
    """Full signed 360-degree great-circle cut, sorted -180..180.

    At positive angles use the first azimuth, negative use the second.
    Both polar poles are shared; each appears only once at +/-180 except
    for the duplicate back endpoint required for continuous polar plots.
    """
    data = np.asarray(db, dtype=float)
    if data.shape != (72, 37):
        raise ValueError(f"Expected (72,37), got {data.shape}")
    if plane not in CUT_AZIMUTHS:
        raise ValueError("plane must be 'H' or 'V'")
    az_positive, az_negative = CUT_AZIMUTHS[plane]
    positive = data[az_positive // 5]
    negative = data[az_negative // 5]
    theta = ARC_DEGREES.copy()
    signed = np.concatenate([-theta[:0:-1], theta])
    levels = np.concatenate([negative[:0:-1], positive])
    if axis_reference_db is not None:
        levels = levels - axis_reference_db
    return signed, levels


def _crossing_angle(rel_branch: np.ndarray, threshold_db: float = DB_BEAMWIDTH) -> float:
    """First -6 dB crossing moving away from the front; NaN if absent."""
    arr = np.asarray(rel_branch, dtype=float)
    for idx in range(1, arr.size):
        a, b = arr[idx - 1], arr[idx]
        if np.isfinite(a) and np.isfinite(b) and a > threshold_db >= b:
            fraction = (threshold_db - a) / (b - a)
            return float(ARC_DEGREES[idx - 1] + 5.0 * fraction)
    return math.nan


def beamwidth_sides(db: np.ndarray, plane: str, axis_reference_db: float) -> Dict[str, float]:
    positive, negative = CUT_AZIMUTHS[plane]
    pos = db[positive // 5] - axis_reference_db
    neg = db[negative // 5] - axis_reference_db
    left_deg = _crossing_angle(neg)
    right_deg = _crossing_angle(pos)
    width = left_deg + right_deg if np.isfinite(left_deg) and np.isfinite(right_deg) else math.nan
    return {"negative_deg": left_deg, "positive_deg": right_deg, "width_deg": width,
            "asymmetry_deg": abs(right_deg - left_deg) if np.isfinite(width) else math.nan}


def measure_directivity(db: np.ndarray, freq_hz: float, *, band_type: str = "third_octave",
                        ea: Optional[Any] = None) -> Dict[str, Any]:
    """Compute per-band directivity metrics preserving stored dB values.

    Directivity magnitude dB -> relative linear POWER = 10**(Drel/10).
    The reference is the median frontal value at arc=0, *not* max(dB).
    DI may be negative for off-axis speakers; it is not silently forced to 0.
    """
    x = np.asarray(db, dtype=float)
    if x.shape != (AZIMUTH_DEGREES.size, ARC_DEGREES.size):
        raise ValueError(f"Expected (72,37), got {x.shape}")

    result: Dict[str, Any] = dict(methodology_version=METHODOLOGY_VERSION,
                                  frequency_hz=float(freq_hz), band_type=band_type,
                                  angular_assumption="polar_arc_0deg_front; H_90_270; V_0_180",
                                  n_angles=int(x.size),
                                  finite_pct=float(100.0 * np.isfinite(x).mean()),
                                  directivity_class="indeterminada", quality_status="invalid",
                                  quality_flags="")
    warnings = []
    if not np.isfinite(x).all():
        warnings.append("nonfinite_samples")
    finite = x[np.isfinite(x)]
    if finite.size and float(finite.min()) < -250:
        warnings.append("extreme_below_minus_250_db_review")
    if finite.size and float(finite.max()) > 100:
        warnings.append("extreme_above_plus_100_db_review")

    metric_names = ["axis_db", "axis_spread_db", "rear_db", "rear_spread_db", "peak_db",
                    "peak_off_axis_db", "peak_azimuth_deg", "peak_arc_deg", "mean_relative_power",
                    "q_integrated", "di_integrated_db", "front_to_back_axial_db",
                    "rear_power_fraction", "rear_power_pct", "h_width_deg", "v_width_deg",
                    "h_negative_deg", "h_positive_deg", "v_negative_deg", "v_positive_deg",
                    "h_asymmetry_deg", "v_asymmetry_deg", "ea_axial_q_raw", "ea_h_left_raw",
                    "ea_h_right_raw", "ea_v_up_raw", "ea_v_down_raw"]
    result.update({name: math.nan for name in metric_names})
    if ea is not None:
        for attr, col in [("axial_q", "ea_axial_q_raw"), ("h_left", "ea_h_left_raw"),
                          ("h_right", "ea_h_right_raw"), ("v_up", "ea_v_up_raw"),
                          ("v_down", "ea_v_down_raw")]:
            result[col] = float(getattr(ea, attr, math.nan))

    if not np.isfinite(x).all():
        result["quality_flags"] = ";".join(warnings)
        return result
    axis = float(np.median(x[:, 0]))
    axis_spread = float(np.ptp(x[:, 0]))
    rear = float(np.median(x[:, -1]))
    rear_spread = float(np.ptp(x[:, -1]))
    idx = np.unravel_index(int(x.argmax()), x.shape)
    peak = float(x[idx]); off_axis = peak - axis
    result.update(axis_db=axis, axis_spread_db=axis_spread, rear_db=rear,
                  rear_spread_db=rear_spread, peak_db=peak, peak_off_axis_db=off_axis,
                  peak_azimuth_deg=float(AZIMUTH_DEGREES[idx[0]]),
                  peak_arc_deg=float(ARC_DEGREES[idx[1]]), front_to_back_axial_db=axis - rear)

    if axis_spread > AXIS_SPREAD_LIMIT_DB or rear_spread > AXIS_SPREAD_LIMIT_DB:
        warnings.append("inconsistent_poles")
    if off_axis > OFF_AXIS_WARNING_DB:
        warnings.append("off_axis_peak_over_3_db")
    # Scientific calculations always use original data (no display floor).
    power = np.power(10., (x - axis) / 10.)
    weights, rear_weights = angular_weights()
    sphere_power = float((power * weights[None, :]).sum() / x.shape[0])
    rear_power = float((power * rear_weights[None, :]).sum() / x.shape[0])
    if not np.isfinite(sphere_power) or sphere_power <= 0:
        warnings.append("invalid_spherical_integral")
        result["quality_flags"] = ";".join(warnings)
        return result
    q = 1.0 / sphere_power
    di = 10.0 * np.log10(q)
    result.update(mean_relative_power=sphere_power, q_integrated=q, di_integrated_db=di,
                  rear_power_fraction=rear_power / sphere_power,
                  rear_power_pct=100 * rear_power / sphere_power)
    for key, plane in [("h", "H"), ("v", "V")]:
        widths = beamwidth_sides(x, plane, axis)
        result[f"{key}_width_deg"] = widths["width_deg"]
        result[f"{key}_negative_deg"] = widths["negative_deg"]
        result[f"{key}_positive_deg"] = widths["positive_deg"]
        result[f"{key}_asymmetry_deg"] = widths["asymmetry_deg"]
        if not np.isfinite(widths["width_deg"]):
            warnings.append(f"no_complete_minus_6db_crossing_{key}")
    reliable = not any(f in warnings for f in ("inconsistent_poles", "invalid_spherical_integral",
                                                  "extreme_below_minus_250_db_review",
                                                  "extreme_above_plus_100_db_review"))
    result["quality_status"] = "ok" if not warnings else "warning"
    result["directivity_class"] = classify_di(di, off_axis, reliable=reliable)
    result["quality_flags"] = ";".join(warnings)
    return result
