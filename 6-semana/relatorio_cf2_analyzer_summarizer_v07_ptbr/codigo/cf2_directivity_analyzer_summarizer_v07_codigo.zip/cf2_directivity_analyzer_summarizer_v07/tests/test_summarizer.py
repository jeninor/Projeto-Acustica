"""Deterministic regression tests for the textual summarizer."""
import csv
import hashlib
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import cf2_summarizer as s

CFG=s.load_cfg()
SHA='a'*64

def row(f=1000.,di=10.,delta=0.,**extra):
    r={'sha256':SHA,'manufacturer':'TEST','model':'ALTAVOZ',
       'filename':'test.CF2','frequency_hz':str(f),'di_integrated_db':str(di),
       'q_integrated':str(10**(di/10)),'peak_off_axis_db':str(delta),
       'peak_arc_deg':'0','h_width_deg':'90','v_width_deg':'40',
       'front_cone_60_power_pct':'60','rear_power_pct':'20',
       'pattern_jsd_vs_previous_bits':'', 'previous_frequency_hz':'',
       'di_change_vs_previous_db':'','ea_check_status':'pass',
       'ea_q_relative_error_pct':'0.001','quality_status':'ok'}
    return {**r,**{k:str(v) for k,v in extra.items()}}

class TestSummarizer(unittest.TestCase):
    def test_frequency_table(self):
        self.assertEqual(len(s.CF2_FREQS),30)
        self.assertTrue(s.is_known_frequency(31.5))
        self.assertFalse(s.is_known_frequency(44000))
    def test_exact_two_di_definitions(self):
        r=s.enrich_row(row(di=-5,delta=9,peak_arc_deg=15),CFG)
        self.assertAlmostEqual(r['di_max_db_v06'],4)
        self.assertEqual(r['clase_di_axial_v06'],'DI negativo respecto a ese eje')
        self.assertEqual(r['clase_di_max_v06'],'moderadamente directivo')
        self.assertIn('eje frontal',r['descripcion_v06'])
    def test_nodelimitado(self):
        r=s.enrich_row(row(h_width_deg='',v_width_deg=''),CFG)
        self.assertEqual(r['estado_v06'],'limitado')
        self.assertIn('no delimitadas',r['descripcion_v06'])
    def test_near_sampling_limit(self):
        r=s.enrich_row(row(v_width_deg='7.3'),CFG)
        self.assertEqual(r['estado_v06'],'limitado')
        self.assertIn('5°',r['descripcion_v06'])
    def test_off_axis_beamwidth_not_main(self):
        r=s.enrich_row(row(delta=5),CFG)
        self.assertEqual(r['estado_v06'],'limitado')
        self.assertIn('haz principal',r['descripcion_v06'])
    def test_jensen_shannon_only_adjacent(self):
        yes=s.enrich_row(row(f=1000,previous_frequency_hz=800,
                   pattern_jsd_vs_previous_bits=.15),CFG)
        no=s.enrich_row(row(f=1000,previous_frequency_hz=500,
                   pattern_jsd_vs_previous_bits=.15),CFG)
        self.assertTrue(yes['banda_previa_contigua_v06'])
        self.assertFalse(no['banda_previa_contigua_v06'])
        self.assertIn('JSD',yes['descripcion_v06'])
        self.assertNotIn('JSD',no['descripcion_v06'])
    def test_ea_discrepancy_flags_review(self):
        r=s.enrich_row(row(ea_q_relative_error_pct=11),CFG)
        self.assertEqual(r['estado_v06'],'revisar')
    def test_dedup_by_hash_and_frequency(self):
        rows=[row(),row(filename='clone.CF2'),row(f=2000)]
        uniq,meta=s.deduplicate(rows)
        self.assertEqual(len(uniq),2)
        self.assertEqual(meta['filas_duplicadas'],1)
        self.assertEqual(meta['conflictos_duplicados'],[])
    def test_conflict_not_silently_mixed(self):
        uniq,meta=s.deduplicate([row(),row(di=20)])
        self.assertEqual(len(uniq),1)
        self.assertTrue(meta['conflictos_duplicados'])
    def test_reject_non_cf2_freq(self):
        uniq,meta=s.deduplicate([row(f=44000)])
        self.assertFalse(uniq)
        self.assertEqual(len(meta['filas_invalidas']),1)
    def test_summary_no_extrapolation(self):
        enriched=[s.enrich_row(row(f=1000),CFG),s.enrich_row(row(f=1250),CFG)]
        info=s.speaker_summary(enriched,CFG)
        self.assertEqual(info['n_bandas'],2)
        self.assertIn('No hay bandas declaradas',info['descripcion_general_v06'])
    def test_end_to_end(self):
        with tempfile.TemporaryDirectory() as t:
            t=Path(t)
            meta=s.run([row(f=1000),row(f=1250)],t,CFG)
            self.assertEqual(meta['archivos_unicos'],1)
            self.assertTrue((t/'resumen_corpus.md').is_file())
            self.assertEqual(len(list((t/'altavoces').glob('*.md'))),1)
            with (t/'catalogo_bandas.csv').open(encoding='utf-8-sig') as f:
                self.assertEqual(len(list(csv.DictReader(f))),2)
    def test_reproducible(self):
        r=s.enrich_row(row(),CFG)
        self.assertEqual(r['descripcion_v06'],s.enrich_row(row(),CFG)['descripcion_v06'])

if __name__=='__main__':unittest.main()
