"""Regression tests for text metadata generation (standard library only)."""
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import cf2_describer_v07 as v07

CFG=json.loads((v07.HERE/'config'/'descripcion_v07.json').read_text())
SHA='a'*64


def make_row(f=1000,di=10,**extras):
    out={'model':'DEMO','manufacturer':'SYNTHETIC','filename':'DEMO.CF2',
         'sha256':SHA,'frequency_hz':str(f),'methodology_version':'0.2.0',
         'di_integrated_db':str(di),'peak_off_axis_db':'0',
         'peak_arc_deg':'0','peak_azimuth_deg':'0','q_integrated':'10',
         'h_width_deg':'120','v_width_deg':'30',
         'front_cone_60_power_pct':'80', 'rear_power_pct':'8',
         'quality_status':'ok','ea_check_status':'pass',
         'h_lobe_candidates_count':'0','v_lobe_candidates_count':'0',
         'previous_frequency_hz':'','pattern_jsd_vs_previous_bits':''}
    return {**out,**{k:str(v) for k,v in extras.items()}}


class DescriberV07Tests(unittest.TestCase):
    def test_di_class_3_6_10(self):
        self.assertEqual(v07.norm_class(2.99,CFG),'poco directivo')
        self.assertEqual(v07.norm_class(3,CFG),'moderadamente directivo')
        self.assertEqual(v07.norm_class(6,CFG),'directivo')
        self.assertEqual(v07.norm_class(10,CFG),'muy directivo')
    def test_axis_peak_difference(self):
        b=v07.classify_band(make_row(12500,1,peak_off_axis_db=13.2,peak_arc_deg=20),CFG)
        self.assertAlmostEqual(b['metricas']['di_max_db'],14.2)
        self.assertIn('maximo_fuera_eje_relevante',b['patron_etiquetas'])
        self.assertIn('desplazado', ' '.join(b['limitaciones']))
    def test_cannot_infer_360_from_missing_width(self):
        b=v07.classify_band(make_row(125,2,h_width_deg='',v_width_deg=''),CFG)
        self.assertIsNone(b['metricas']['beamwidth_h_deg'])
        self.assertIn('No es posible describir ambos anchos',b['interpretacion_acustica'])
        self.assertEqual(b['estado_interpretacion'],'condicionado')
    def test_hv_provisional_anisotropy(self):
        b=v07.classify_band(make_row(1000,10,h_width_deg=200,v_width_deg=30),CFG)
        self.assertIn('cobertura_anisotropica_cortes',b['patron_etiquetas'])
        self.assertIn('provisional',b['interpretacion_acustica'])
    def test_cut_lobes_not_3d_proof(self):
        b=v07.classify_band(make_row(h_lobe_candidates_count=2,v_lobe_candidates_count=1),CFG)
        self.assertIn('no lóbulos 3D confirmados',b['interpretacion_acustica'])
    def test_adjacency_only_one_third_octave(self):
        before=make_row(1000,10)
        after=make_row(2000,14,previous_frequency_hz=1000,pattern_jsd_vs_previous_bits=0.6)
        result=v07.classify_band(after,CFG,before)
        self.assertFalse(result['transicion_desde_anterior']['contiguas'])
        self.assertNotIn('cambio notablemente',result['interpretacion_acustica'])
    def test_adjacency_jsd_source_matching(self):
        before=make_row(1000,10)
        after=make_row(1250,14,previous_frequency_hz=1000,pattern_jsd_vs_previous_bits=0.3)
        r=v07.classify_band(after,CFG,before)
        self.assertTrue(r['transicion_desde_anterior']['cambio_espacial_destacado'])
        self.assertTrue(r['transicion_desde_anterior']['cambio_di_destacado'])
        wrong=make_row(1250,14,previous_frequency_hz=800,pattern_jsd_vs_previous_bits=0.3)
        self.assertIsNone(v07.classify_band(wrong,CFG,before)['transicion_desde_anterior']['jsd_bits'])
    def test_three_text_levels(self):
        b=v07.classify_band(make_row(),CFG)
        for field in ('resumen_breve','descripcion_tecnica','interpretacion_acustica'):
            self.assertTrue(len(b[field])>15,field)
    def test_all_frequencies_and_no_resampling(self):
        self.assertEqual(len(v07.FREQUENCIES),30)
        self.assertEqual(v07.FREQUENCIES[0],25)
        self.assertEqual(v07.FREQUENCIES[-1],20000)
    def test_profile_bands_and_metadata(self):
        profile=v07.aggregate_speaker([make_row(1000,7),make_row(1250,11,previous_frequency_hz=1000)],CFG)
        self.assertEqual(profile['coverage']['n_bands'],2)
        self.assertEqual(len(profile['bands']),2)
        self.assertEqual(profile['schema_version'],'cf2.directivity.speaker.v0.7')
        md=v07.markdown_report(profile)
        self.assertIn('### 1.000 Hz',md)
        self.assertIn('### 1.250 Hz',md)
        self.assertIn('no se calculan rankings',profile['methodology']['selection'])


if __name__=='__main__': unittest.main()
