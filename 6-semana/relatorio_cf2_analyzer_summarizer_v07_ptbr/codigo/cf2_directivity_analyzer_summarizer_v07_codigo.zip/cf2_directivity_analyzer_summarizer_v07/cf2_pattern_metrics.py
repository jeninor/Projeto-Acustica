#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Experimental spatial-pattern descriptors for CF2 directivity (v0.2).

Raw CF2 data are never overwritten. 'Lobe candidates' are heuristics found
on two 5-degree planar cuts, NOT authoritative 3D sidelobe counts.
Angular integration assumes arc=polar angle from the forward axis.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from cf2_parser_v5 import ARC_DEGREES
from cf2_directivity_metrics import angle_plane_cut, angular_weights

EXPERIMENTAL_METHOD = "0.2.0"


def _shape_ok(db: np.ndarray) -> np.ndarray:
    x = np.asarray(db, dtype=float)
    if x.shape != (72, 37):
        raise ValueError(f"Directivity shape must be (72,37), got {x.shape}")
    return x


def sphere_power_probabilities(db: np.ndarray) -> np.ndarray:
    """Power probability mass per angular cell, normalized on 4π sphere.

    Invariant to global dB offsets. Returns NaN grid on nonfinite inputs.
    Computation shifts by max to handle very low literal levels (e.g. -200 dB).
    """
    x = _shape_ok(db)
    if not np.isfinite(x).all():
        return np.full(x.shape, np.nan)
    w, _ = angular_weights()
    cell_mass = np.exp((x - float(x.max())) * (np.log(10.0) / 10.0)) * w[None, :]
    cell_mass = cell_mass / 72.0
    z = float(cell_mass.sum())
    return cell_mass / z if np.isfinite(z) and z > 0 else np.full(x.shape, np.nan)


def cone_weights(angle_deg: float) -> np.ndarray:
    """Fraction of 4π owned by each polar ring and inside cone θ<=angle_deg.

    Output ring weights sum to (1-cos(angle))/2, not one; 72 rows later
    receive identical ring weights/72. Edges are halfway between 5° samples.
    """
    if not 0 <= angle_deg <= 180:
        raise ValueError("Cone half-angle must be within [0,180]")
    t = np.deg2rad(ARC_DEGREES.astype(float))
    edges = np.empty(t.size + 1, float)
    edges[0], edges[-1] = 0.0, np.pi
    edges[1:-1] = (t[:-1] + t[1:]) / 2.0
    limit = np.deg2rad(float(angle_deg))
    end = np.minimum(edges[1:], limit)
    weight = np.where(end > edges[:-1],
                      (np.cos(edges[:-1]) - np.cos(end)) / 2.0, 0.0)
    return weight


def cone_energy_fraction(db: np.ndarray, angle_deg: float) -> float:
    """Fraction of emitted relative *power* inside a forward cone."""
    probs = sphere_power_probabilities(db)
    if not np.isfinite(probs).all():
        return math.nan
    total, _ = angular_weights()
    subset = cone_weights(angle_deg)
    return float(np.sum(probs * (subset / total)[None, :]))


def _weighted_quantile(vals: np.ndarray, weights: np.ndarray, quantile: float) -> float:
    v, w = np.asarray(vals, float).ravel(), np.asarray(weights, float).ravel()
    mask = np.isfinite(v) & np.isfinite(w) & (w > 0)
    if not mask.any():
        return math.nan
    v, w = v[mask], w[mask]
    idx = np.argsort(v, kind="stable")
    v, w = v[idx], w[idx]
    cum = np.cumsum(w)
    return float(np.interp(float(quantile) * cum[-1], cum, v))


def front_cone_level_range(db: np.ndarray, cone_deg: float = 60) -> float:
    """Weighted P90-P10 of dB levels in a front cone. NOT room uniformity.

    This value captures variation within a fixed aperture; narrow beams may
    have high variation naturally. It must not be interpreted as dispersion of
    spatial SPL in a room.
    """
    x = _shape_ok(db)
    if not np.isfinite(x).all():
        return math.nan
    w = np.broadcast_to(cone_weights(cone_deg)[None, :], x.shape)
    return _weighted_quantile(x, w, .9) - _weighted_quantile(x, w, .1)


def _local_lobe_candidates(degrees: np.ndarray, relative_db: np.ndarray,
                           *, search_start_deg: float, min_prom_db: float = 3.0,
                           min_level_db: float = -25.0) -> List[Tuple[float, float, float]]:
    """List signed-angle, relative dB, local-prominence of candidate cut peaks.

    Signed -180 and +180 are the same point; use a periodic 72-point curve.
    Candidate has two nearby valleys (within 15°), ≥3 dB below the peak;
    the cut peak must be at least -25 dB relative to the frontal axis.
    """
    deg, val = degrees[:-1], relative_db[:-1]  # remove duplicate +180
    if val.size != 72:
        raise ValueError("Expected 72 unique angular cut points")
    if not np.isfinite(val).all():
        return []
    peaks = []
    for i, (angle, v) in enumerate(zip(deg, val)):
        if abs(angle) < search_start_deg or v < min_level_db:
            continue
        before = val[(i - 1) % 72]
        after = val[(i + 1) % 72]
        if not (v > before and v >= after):
            continue
        left_min = min(val[(i - k) % 72] for k in (1, 2, 3))
        right_min = min(val[(i + k) % 72] for k in (1, 2, 3))
        prom = min(v - left_min, v - right_min)
        if prom >= min_prom_db:
            peaks.append((float(angle), float(v), float(prom)))
    # Prevent adjacent ripples from being counted as separate physical lobes.
    peaks.sort(key=lambda t: t[1], reverse=True)
    kept: List[Tuple[float, float, float]] = []
    for candidate in peaks:
        if all(abs((candidate[0] - q[0] + 180) % 360 - 180) >= 15 for q in kept):
            kept.append(candidate)
    return sorted(kept, key=lambda t: t[0])


def measure_cut_lobe_candidates(db: np.ndarray, plane: str, *,
                                negative_crossing: float = math.nan,
                                positive_crossing: float = math.nan) -> List[Tuple[float, float, float]]:
    x = _shape_ok(db)
    if not np.isfinite(x).all():
        return []
    front = float(np.median(x[:, 0]))
    angles, rel = angle_plane_cut(x, plane, axis_reference_db=front)
    # Avoid classing the main beam shoulder as a secondary lobe. If the beam
    # is unbounded, use an exploratory 30° exclusion cone instead.
    if np.isfinite(negative_crossing) and np.isfinite(positive_crossing):
        outside = 10.0 + max(float(negative_crossing), float(positive_crossing))
    else:
        outside = 30.0
    return _local_lobe_candidates(angles, rel, search_start_deg=outside)


def pattern_metrics(db: np.ndarray, existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Metrics that complement v0.1, without redefining Q, DI or beamwidth."""
    x = _shape_ok(db)
    res: Dict[str, Any] = dict(
        front_cone_30_power_pct=math.nan,
        front_cone_60_power_pct=math.nan,
        front_hemisphere_power_pct=math.nan,
        front60_level_p90_p10_db=math.nan,
        bw_anisotropy_ratio_h_over_v=math.nan,
        h_lobe_candidates_count=math.nan,
        v_lobe_candidates_count=math.nan,
        h_strongest_lobe_relative_db=math.nan,
        v_strongest_lobe_relative_db=math.nan,
        lobe_method="cut_candidates_3dB_prom_15deg_span_min_minus25dB_not_true_3D_lobes",
    )
    if not np.isfinite(x).all():
        return res
    res['front_cone_30_power_pct'] = 100. * cone_energy_fraction(x, 30)
    res['front_cone_60_power_pct'] = 100. * cone_energy_fraction(x, 60)
    res['front_hemisphere_power_pct'] = 100. * cone_energy_fraction(x, 90)
    res['front60_level_p90_p10_db'] = front_cone_level_range(x, 60)
    if existing:
        h, v = existing.get('h_width_deg', math.nan), existing.get('v_width_deg', math.nan)
        if np.isfinite(h) and np.isfinite(v) and v > 0:
            res['bw_anisotropy_ratio_h_over_v'] = float(h/v)
    for plane in ('H', 'V'):
        prefix = plane.lower()
        candidate = measure_cut_lobe_candidates(
            x, plane,
            negative_crossing=(existing or {}).get(prefix+'_negative_deg', math.nan),
            positive_crossing=(existing or {}).get(prefix+'_positive_deg', math.nan),
        )
        res[prefix+'_lobe_candidates_count'] = len(candidate)
        if candidate:
            res[prefix+'_strongest_lobe_relative_db'] = max(c[1] for c in candidate)
    return res


def jensen_shannon_divergence_bits(db_a: np.ndarray, db_b: np.ndarray) -> float:
    """JSD of two angular *power distributions*, bits, 0..1.

    0 = identical normalized angular power patterns. Compares complete 3D
    balloons; unaffected by global dB offsets and without arbitrary dB floors.
    Supports zero-mass bins (e.g. literal -200 dB).
    """
    p = sphere_power_probabilities(db_a).ravel()
    q = sphere_power_probabilities(db_b).ravel()
    if not np.isfinite(p).all() or not np.isfinite(q).all():
        return math.nan
    m = .5 * (p + q)
    term_p = np.sum(p[p>0] * np.log2(p[p>0] / m[p>0]))
    term_q = np.sum(q[q>0] * np.log2(q[q>0] / m[q>0]))
    return float(np.clip(.5 * (term_p + term_q), 0, 1))


def attach_spectral_differences(records: List[Dict[str, Any]],
                                surfaces: Dict[float, np.ndarray]) -> None:
    """Mutates per-band rows, adding previous-adjacent-band comparisons."""
    prev_freq = None
    for r in sorted(records, key=lambda z: float(z['frequency_hz'])):
        curr = float(r['frequency_hz'])
        r['previous_frequency_hz'] = prev_freq if prev_freq is not None else math.nan
        r['pattern_jsd_vs_previous_bits'] = (jensen_shannon_divergence_bits(surfaces[prev_freq], surfaces[curr])
                                             if prev_freq is not None else math.nan)
        r['di_change_vs_previous_db'] = (float(r['di_integrated_db']) -
                                          float(next(x['di_integrated_db'] for x in records
                                                     if float(x['frequency_hz']) == prev_freq))
                                          if prev_freq is not None else math.nan)
        prev_freq = curr


def ea_consistency_metrics(existing: Dict[str, Any]) -> Dict[str, Any]:
    """Independent self-consistency checks against EA metadata, where valid.

    EA fields can be uninitialized or conventions may differ by exporter.
    A mismatch is a *diagnostic*, never silently used to fix balloon data.
    """
    def valid(v: Any, *, positive: bool = False) -> bool:
        try:
            v = float(v)
            return bool(np.isfinite(v) and abs(v + 12000.0) > 1e-3 and
                        abs(v) < 1e8 and (v > 0 if positive else v >= 0))
        except (TypeError, ValueError):
            return False

    out = dict(ea_q_relative_error_pct=math.nan,
               ea_h_width_error_abs_deg=math.nan,
               ea_v_width_error_abs_deg=math.nan,
               ea_check_status='not_comparable')
    checks = []
    measured_q, ea_q = existing.get('q_integrated'), existing.get('ea_axial_q_raw')
    if valid(measured_q, positive=True) and valid(ea_q, positive=True):
        out['ea_q_relative_error_pct'] = abs(float(measured_q)-float(ea_q)) / float(ea_q) * 100.0
        checks.append(('q', out['ea_q_relative_error_pct'] <= 5.0))
    for plane, keys in [('h', ('ea_h_left_raw','ea_h_right_raw')),
                        ('v', ('ea_v_up_raw', 'ea_v_down_raw'))]:
        ea_side = [existing.get(k) for k in keys]
        own = existing.get(plane+'_width_deg')
        if valid(own) and all(valid(v) for v in ea_side):
            error = abs(float(own) - sum(map(float, ea_side)))
            out[f'ea_{plane}_width_error_abs_deg'] = error
            checks.append((plane, error <= 10.0))
    if checks:
        out['ea_check_status'] = 'pass' if all(ok for _,ok in checks) else 'review'
    return out
